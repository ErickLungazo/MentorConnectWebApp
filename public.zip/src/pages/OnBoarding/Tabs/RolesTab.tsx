
import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card"
import RoleForm from "@/components/forms/RoleForm.tsx";

const RolesTab = () => {
    return (
        <section className={"flex items-center justify-center min-h-screen py-5"}>
            <Card className={"max-w-xl w-full"}>
                <CardHeader>
                    <CardTitle>Role</CardTitle>
                    <CardDescription>Select your role</CardDescription>
                </CardHeader>
                <CardContent>
<RoleForm/>                </CardContent>
                <CardFooter>
                    <p>
                        Mentor/Mentee
                    </p>
                </CardFooter>
            </Card>

        </section>
    );
};

export default RolesTab;