import RolesTab from "@/pages/OnBoarding/Tabs/RolesTab.tsx";

const MentorSteps=[
   {
        id:1,
        title:"Personal Information",
        tab:<RolesTab/>

    }, {
        id:1,
        title:"Academic Qualifications",
        tab:<RolesTab/>

    }, {
        id:1,
        title:"Professional Information",
        tab:<RolesTab/>

    }
]
const Mentee=[
     {
        id:1,
        title:"Personal Information",
        tab:<RolesTab/>

    }, {
        id:1,
        title:"Academic Qualifications",
        tab:<RolesTab/>

    }, {
        id:1,
        title:"Professional Information",
        tab:<RolesTab/>

    }
]
const OnBoardingPage = () => {
    return (
        <div>
            <RolesTab/>
        </div>
    );
};

export default OnBoardingPage;