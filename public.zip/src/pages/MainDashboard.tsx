import OnBoardingPage from "@/pages/OnBoarding/OnBoardingPage.tsx";

const MainDashboard = () => {
    return (
        <div>
           <OnBoardingPage/>
        </div>
    );
};

export default MainDashboard;