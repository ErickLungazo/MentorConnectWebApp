import {BrowserRouter as Router, Routes, Route,} from "react-router-dom";
import MainDashboard from "@/pages/MainDashboard.tsx";
import NotFoundPage from "@/pages/NotFoundPage.tsx";
import RegisterPage from "@/pages/auth/RegisterPage.tsx";
import LoginPage from "@/pages/auth/LoginPage.tsx";
import {Toaster} from "@/components/ui/sonner.tsx";
import ProtectedRoute from "@/layout/ProtectedRoute.tsx";

const App = () => {
    return (
        <div>
            <Toaster richColors position={"top-right"}/>
            <Router>
                <Routes>
                    <Route path={"/login"} element={<LoginPage/>}/>
                    <Route path={"/register"} element={<RegisterPage/>}/>
                    <Route path={"*"} element={<NotFoundPage/>}/>
                    <Route path={"/"} element={
                        <ProtectedRoute>

                            <MainDashboard/>
                        </ProtectedRoute>
                    }/>
                </Routes>
            </Router>
        </div>
    );
};

export default App;