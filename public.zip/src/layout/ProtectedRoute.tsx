// ProtectedRoute.tsx
import React, { useEffect, useState } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { supabase } from "@/lib/supabase.ts";
import {toast} from "sonner"; // Adjust the path as necessary

const ProtectedRoute: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
    const location = useLocation();
    const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

    useEffect(() => {
        const checkAuthentication = async () => {
            try {
                const { data } = await supabase.auth.getSession();
                setIsAuthenticated(!!data.session);
            } catch (error) {
                console.error("Error checking authentication:", error);
                toast.error("Login to continue");

                setIsAuthenticated(false);
            }
        };

        checkAuthentication();
    }, []);

    if (isAuthenticated === null) {
        // Loading state
        return <div>Loading...</div>;
    }

    return (
        isAuthenticated ? (
            children ? (
                children
            ) : (
                <Outlet />
            )
        ) : (
            <Navigate to="/login" state={{ from: location }} replace />
        )
    );
};

export default ProtectedRoute;